package com.example.unccrudapp;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.unccrudapp.model.User;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.MyViewHolder> {
    private SwipeRefreshLayout refreshLayout;
    private RequestQueue requestQueue;
    private JsonArrayRequest arrayRequest;
    private Context context;
    private ArrayList<User> user;
    private String url = "";
    private UserAdapter userAdapter;
    private RecyclerView recyclerView;

    public UserAdapter(Context context, ArrayList<User> user) {
        this.context = context;
        this.user = user;
    }

    @NonNull
    @Override
    public UserAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;

        LayoutInflater layoutInflater = LayoutInflater.from(context);
        view = layoutInflater.inflate(R.layout.user_list, parent, false);

        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull UserAdapter.MyViewHolder holder, int position) {
        holder.txtNome.setText(user.get(position).getNome());
        holder.txtNumber.setText(String.valueOf(position + 1));
        holder.edtUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String id = user.get(position).getId();
                String nome = user.get(position).getNome();
                String sobrenome = user.get(position).getSobrenome();
                String nascimento = user.get(position).getNascimento();
                String login = user.get(position).getLogin();
                String password = user.get(position).getPassword();
                String dica = user.get(position).getDica();
                String cidade = user.get(position).getCidade();
                String estado = user.get(position).getEstado();
                JSONObject object = new JSONObject();
                try {
                    object.put("_id", id);
                    object.put("nome", nome);
                    object.put("sobrenome", sobrenome);
                    object.put("nascimento", nascimento);
                    object.put("login", login);
                    object.put("password", password);
                    object.put("dica", dica);
                    object.put("cidade" , cidade);
                    object.put("estado" , estado);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                editUser(id, object);
            }
        });
        holder.deleteUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String id = user.get(position).getId();
                deleteUser(id);
            }
        });
    }

    private void deleteUser(final String id) {
        TextView txtUser, txtClose;
        Button btnSave;
        final Dialog dialog;

        dialog = new Dialog(context);

        dialog.setContentView(R.layout.user_delete);

        txtClose = (TextView) dialog.findViewById(R.id.txtClose);
        txtUser = (TextView) dialog.findViewById(R.id.txtUser);

        txtUser.setText("Excluir Usuário");

        txtClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        btnSave = (Button) dialog.findViewById(R.id.btnDelete);
        String userId = id;
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                delete(dialog, userId);
            }
        });
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.show();
    }

    private void delete(Dialog dialog, String userId) {
        String url = "http://10.0.2.2:3000/users/delete/" + userId;
        StringRequest stringRequest = new StringRequest(Request.Method.DELETE, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                dialog.dismiss();
                Toast.makeText(context, "Dados excluídos com sucesso!", Toast.LENGTH_LONG).show();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(context, error.toString(), Toast.LENGTH_LONG).show();
            }
        }) { };

        Volley.newRequestQueue(context).add(stringRequest);
    }

    private void editUser(final String id, JSONObject object) {
        TextView txtUser, txtClose;
        EditText edtNome, edtSobrenome, edtNascimento, edtLogin, edtPassword, edtDica, edtCidade, edtEstado;
        Button btnSave;
        final Dialog dialog;

        dialog = new Dialog(context);

        dialog.setContentView(R.layout.activity_moduser);

        txtClose = (TextView) dialog.findViewById(R.id.txtClose);
        txtUser = (TextView) dialog.findViewById(R.id.txtUser);

        txtUser.setText("Alterar Usuário");

        txtClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        edtNome = (EditText) dialog.findViewById(R.id.edtNome);
        edtSobrenome = (EditText) dialog.findViewById(R.id.edtSobrenome);
        edtNascimento = (EditText) dialog.findViewById(R.id.edtNascimento);
        edtLogin = (EditText) dialog.findViewById(R.id.edtLogin);
        edtPassword = (EditText) dialog.findViewById(R.id.edtPass);
        edtDica = (EditText) dialog.findViewById(R.id.edtDica);
        edtCidade = (EditText) dialog.findViewById(R.id.edtCidade);
        edtEstado = (EditText) dialog.findViewById(R.id.edtEstado);

        btnSave = (Button) dialog.findViewById(R.id.btnSave);
        String userId = null;
        try {
            userId = object.getString("_id");
            edtNome.setText(object.getString("nome"));
            edtSobrenome.setText(object.getString("sobrenome"));
            edtNascimento.setText(object.getString("nascimento"));
            edtLogin.setText(object.getString("login"));
            edtDica.setText(object.getString("dica"));
            edtCidade.setText(object.getString("cidade"));
            edtEstado.setText(object.getString("estado"));
        } catch (JSONException e) {
            e.printStackTrace();
        }

        String finalUserId = userId;
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                JSONObject object = new JSONObject();
                try {
                    object.put("_id", finalUserId);
                    object.put("nome", edtNome.getText());
                    object.put("sobrenome", edtSobrenome.getText());
                    object.put("nascimento", edtNascimento.getText());
                    object.put("login", edtLogin.getText());
                    object.put("password", edtPassword.getText());
                    object.put("dica", edtDica.getText());
                    object.put("cidade", edtCidade.getText());
                    object.put("estado", edtEstado.getText());
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                submit(object, dialog, finalUserId);
            }
        });
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.show();
    }

    private void submit(final JSONObject object, final Dialog dialog, String id) {
        String url = "http://10.0.2.2:3000/users/update/" + id;
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.PUT, url, object, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                dialog.dismiss();
                /*
                refreshLayout.post(new Runnable() {
                    @Override
                    public void run() {
                        user.clear();
                        getData();
                    }
                });
                 */
                Toast.makeText(context, "Dados alterados com sucesso!", Toast.LENGTH_LONG).show();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                //Toast.makeText(getApplicationContext(), "Erro ao alterar dados!", Toast.LENGTH_LONG).show();
                Toast.makeText(context, error.toString(), Toast.LENGTH_LONG).show();
            }
        }) { };

        Volley.newRequestQueue(context).add(jsonObjectRequest);
    }

    private void getData() {
        refreshLayout.setRefreshing(true);

        arrayRequest = new JsonArrayRequest(url, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                JSONObject jsonObject = null;
                for (int i = 0; i < response.length(); i++) {
                    try {
                        jsonObject = response.getJSONObject(i);
                        User u = new User();
                        u.setId(jsonObject.getString("_id"));
                        u.setNome(jsonObject.getString("nome"));
                        u.setSobrenome(jsonObject.getString("sobrenome"));
                        u.setNascimento(jsonObject.getString("nascimento"));
                        u.setLogin(jsonObject.getString("login"));
                        u.setDica(jsonObject.getString("dica"));
                        u.setCidade(jsonObject.getString("cidade"));
                        u.setEstado(jsonObject.getString("estado"));
                        user.add(u);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                adapterPush(user);
                refreshLayout.setRefreshing(false);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                //Toast.makeText(getApplicationContext(),error.toString(),Toast.LENGTH_SHORT).show();
            }
        });

        //requestQueue = Volley.newRequestQueue(MainActivity.this);
        //requestQueue.add(arrayRequest);
    }

    private void adapterPush(ArrayList<User> user) {
        //userAdapter = new UserAdapter(this, user);
        //recyclerView.setLayoutManager(new LinearLayoutManager(this));
        //recyclerView.setAdapter(userAdapter);
    }

    @Override
    public int getItemCount() {
        return user.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private TextView txtNome, txtNumber;
        private ImageView edtUser, deleteUser;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            txtNumber = (TextView) itemView.findViewById(R.id.idNumber);
            txtNome = (TextView) itemView.findViewById(R.id.nomeUser);
            edtUser = (ImageView) itemView.findViewById(R.id.editUser);
            deleteUser = (ImageView) itemView.findViewById(R.id.deleteUser);
        }
    }
}
